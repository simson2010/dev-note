//
//  main.m
//  Blocktest
//
//  Created by ws on 2020/4/2.
//

#import <Foundation/Foundation.h>

int main() {
   
    int a = 1;
    void(^__strong block)(void) = ^{
        NSLog(@"block---%d", a);
    };
    block();
    id objBlock = block;
    NSLog(@"%@", objBlock);
}
// block copy
// a.源码搜素
// (.*)[bB]lock(.*)[Cc]opy(.*)

//br set --func-regex=(.*)[bB]lock(.*)[Cc]opy(.*)
//
//br set -r (.*)[bB]lock(.*)[Cc]opy(.*)
//
//rb (.*)[bB]lock(.*)[Cc]opy(.*)
//
//rb (.*)[bB]lock(.*)[Cc]opy(.*) --shlib=libsymtem_blocks.dylib
//
//rb (.*)[bB]lock(.*)[Cc]opy(.*) --shlib=libsystem_blocks.dylib
//
//rb (.*)[bB]lock(.*)[Cc]opy(.*) -s libsystem_blocks.dylib
//
//rb (.*)[bB]lock(.*)[Cc]opy(.*) -s libsystem_blocks.dylib
//breakpoint set --source-pattern-regexp=(.*)[bB]lock(.*)[Cc]opy(.*) --file runtime.cpp
//rb (.*)[bB]lock(.*)[Cc]opy(.*) -s libsystem_blocks.dylib
//
//breakpoint set --source-pattern-regexp=(.*)[bB]lock(.*)[Cc]opy(.*) --file runtime.cpp
//
//br set -p (.*)[bB]lock(.*)[Cc]opy(.*) -f runtime.cpp
//
//command alias pb breakpoint set -p %1 -f %2
//
//pb (.*)[bB]lock(.*)[Cc]opy(.*) runtime.cpp






